#!/usr/bin/env bash

luacheck `find ./lua -name "*.lua"` --codes
