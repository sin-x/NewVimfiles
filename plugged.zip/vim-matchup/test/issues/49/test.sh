# `%` jumps to fi
if test -z ""; then
    echo "cursor_position"
else
    true
fi

