# Mintty/WSLtty

## Screenshots
![screenshot: mintty_dark.png](../screenshots/mintty_dark.png)
![screenshot: mintty_light.png](../screenshots/mintty_light.png)

## Installation

Download and move theme files `mintty\onehalf*` to `%APPDATA%\mintty\themes`. Replace `mintty` with `wsltty` for WSLtty.

Then open Mintty/WSLtty, select Options > Looks > Theme > onehalfdark/onehalflight.

