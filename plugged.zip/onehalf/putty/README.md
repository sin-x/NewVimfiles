# PuTTY

These registry files will configure Putty to use the colors for the "one half" theme.

To install, simply download the version of your choice and double click on on it.
